import { Component, OnInit } from '@angular/core';
import {HotelList} from 'src/app/model/hotel-list';
@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public Hotels: HotelList[] = [
    {
      id: 1,
      name: 'RRN',
      city: 'Silk Board, Bangalore',
      availability: true,
      roomsAvailable: 2,
      startHotel: 3,
      wiFi: true,
      ac: true,
      meals: true,
      charge: 1200,
      restaurant: true,
      couple: true
    },
    {
      id: 1,
      name: 'RRN',
      city: 'Silk Board, Bangalore',
      availability: true,
      roomsAvailable: 2,
      startHotel: 3,
      wiFi: true,
      ac: true,
      meals: true,
      charge: 1200,
      restaurant: true,
      couple: true
    },
    {
      id: 1,
      name: 'RRN',
      city: 'Silk Board, Bangalore',
      availability: true,
      roomsAvailable: 2,
      startHotel: 3,
      wiFi: true,
      ac: true,
      meals: true,
      charge: 1200,
      restaurant: true,
      couple: true
    },
    {
      id: 1,
      name: 'RRN',
      city: 'Silk Board, Bangalore',
      availability: true,
      roomsAvailable: 2,
      startHotel: 3,
      wiFi: true,
      ac: true,
      meals: true,
      charge: 1200,
      restaurant: true,
      couple: true
    },
    {
      id: 1,
      name: 'RRN',
      city: 'Silk Board, Bangalore',
      availability: true,
      roomsAvailable: 2,
      startHotel: 3,
      wiFi: true,
      ac: true,
      meals: true,
      charge: 1200,
      restaurant: true,
      couple: true
    }
  ];


}
