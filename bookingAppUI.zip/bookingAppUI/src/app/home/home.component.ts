import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { HotelFilter } from 'src/app/model/hotel-filter';
import { FindHotelService } from 'src/app/services/find-hotel.service';
import {LoginService} from 'src/app/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loginForm : FormGroup;
  constructor(
    private formBuilder : FormBuilder,
    public loginService : LoginService,
    private router: Router
  ) { }

  ngOnInit() {
    this.createForm();
  }

  public createForm = () => {
    this.loginForm = this.formBuilder.group({
      facilities : [''] ,
       locations: '',
       rooms : '',
       star : '',
       person : ''
    });
  }

}
