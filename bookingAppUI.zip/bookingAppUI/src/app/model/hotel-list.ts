export class HotelList {
    public id: number;
    public name: string;
    public city: string;
    public availability: boolean;
    public roomsAvailable: number;
    public startHotel: number;
    public wiFi: boolean;
    public ac: boolean;
    public meals: boolean
    public charge: number;
    public restaurant: boolean;
    public couple: boolean;
}
