import { HotelFilter } from './hotel-filter';

describe('HotelFilter', () => {
  it('should create an instance', () => {
    expect(new HotelFilter()).toBeTruthy();
  });
});
