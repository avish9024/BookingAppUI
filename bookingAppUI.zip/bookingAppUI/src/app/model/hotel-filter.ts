export class HotelFilter {
    public location ?: string;
    public date ?: Date;
    public wifi ?: boolean;
    public cctv ?: boolean;
    public resturent ?: boolean;
    public rooms ?: number;
    public person ?: number;
    public start ?: number;
    public ratings ?: number;
}
