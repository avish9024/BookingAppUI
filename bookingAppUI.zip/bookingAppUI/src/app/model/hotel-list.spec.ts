import { HotelList } from './hotel-list';

describe('HotelList', () => {
  it('should create an instance', () => {
    expect(new HotelList()).toBeTruthy();
  });
});
